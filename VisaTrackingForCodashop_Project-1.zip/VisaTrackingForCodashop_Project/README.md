# Visa Tracking For Codashop (Android project)

Offline WebView Android wrapper project. UI is in `app/src/main/assets/index.html`.

## Build APK using GitHub Actions
1. Upload this project to a GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Open Actions -> Build Android APK -> Run workflow.
3. After it finishes, download the `VisaTrackingForCodashop-debug-apk` artifact.

The app is portrait-only and uses a compact centered UI design with a 430px maximum design width.

**Security note:** Do not store card CVV in this offline app. It contains card nickname, last four digits and notes only. Avoid storing full card numbers or sensitive payment details.


**UI sizing:** The app UI uses a fixed 430 CSS-pixel design width (not a responsive fluid layout). On narrower devices, some horizontal clipping may occur by design.
