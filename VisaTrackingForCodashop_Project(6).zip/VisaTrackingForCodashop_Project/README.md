# Visa Tracking For Codashop (Android project)

Offline WebView Android wrapper project. UI is in `app/src/main/assets/index.html`.

## Build APK using GitHub Actions
1. Upload this project to a GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Open Actions -> Build Android APK -> Run workflow.
3. After it finishes, download the `VisaTrackingForCodashop-debug-apk` artifact.

The app is portrait-only and uses a compact centered UI design with a 430px maximum design width.

**Security note:** Do not store card CVV in this offline app. It contains card nickname, last four digits and notes only. Avoid storing full card numbers or sensitive payment details.


### Fixed dashboard layout update
Dashboard is locked to the device viewport: no page-level vertical/horizontal dragging. Dashboard summary, action buttons and tabs stay fixed; card list can scroll vertically inside its own area if there are many cards. Other app sections scroll vertically only, never horizontally.


### Zoom lock update
- Viewport is locked to device width, minimum/maximum scale 1.0, and user scaling disabled.
- Android WebView pinch zoom and text auto-zoom are disabled; text zoom is fixed at 100%.
- Double-tap zoom is blocked in the page.
