Visa Tracking For Codashop Android wrapper project (offline WebView)

This is an Android Studio project, not a precompiled APK. This environment does not have Android SDK/Gradle build tools installed, so I cannot compile a verified APK here.

Build APK:
1. Install Android Studio on a computer and open this WalletTrackerAndroid folder.
2. Allow Gradle sync / SDK installation if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

The HTML app is packaged in app/src/main/assets/index.html and uses local browser storage in the app's WebView. Internet permission is not declared; the app is offline-only.
